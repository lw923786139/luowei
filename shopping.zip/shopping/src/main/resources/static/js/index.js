function addShopping(thi){
	var arr = $(thi).parent().parent().children();
	var name = $(arr).eq(0).text();
	var price = $(arr).eq(1).text();
	console.log(name)
	location.href="pay/msginfo?name="+name+"&price="+price;
} 