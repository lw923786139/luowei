$(document).ready(function(){
	$("#unionpay").on("click",function(){
		uniompay();
	});
});

function uniompay(){
	var  name = $("#name").html();
	var price = $("#price").html();
	if(!window.confirm("确定")){
		return;
	}
	location.href="/pay/frontConsume?name="+name+"&price="+price;
	
	/*
	$.ajax({type:'post',
		async:false,
		dataType:'json',
		data:{name:name,price:price},
		url:"/pay/frontConsume"});*/
	
	/*var merId;
	var version;
	var encoding;
	var signMethod;
	var frontUrl;
	var backUrl;
	var frontTransUrl;
	
	jQuery.i18n.properties({
		name:"uniompay",
		path:"/properties/",
		mode:"map",
		callback:function(){
			merId=$.i18n.prop("merId");
			version=$.i18n.prop("version");
			encoding=$.i18n.prop("encoding");
			signMethod=$.i18n.prop("signMethod");
			frontUrl=$.i18n.prop("frontUrl");
			backUrl=$.i18n.prop("backUrl");
			frontTransUrl=$.i18n.prop("frontTransUrl");
		}
	 });
	var date = new Date();
	var dateTime =""+date.getFullYear()+(date.getMonth()+1)+date.getHours()+date.getMinutes()+date.getSeconds();
	var data={
			  version:version,
			  encoding:encoding,
			  signMethod:signMethod,
			  txnType:'01',
			  txnSubType:'01',
			  bizType:'000201',
			  channelType:'07',
			  merId:merId,
			  accessType:'0',
			  orderId:dateTime,
			  txnTime:dateTime,
			  currencyCode:'156',
			  txnAmt:price,
			  riskRateInfo:name,
			  frontUrl:frontUrl,
			  backUrl:backUrl,
			  payTimeout:date.getTime()+15 * 60 * 1000};
	console.log(data);
	$.ajax({type:'post',
			async:false,
			dataType:'json',
			data:data,
			url:frontTransUrl});
	*/
	
}