package com.example.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.unionpay.acp.sdk.SDKConfig;

public class UniompayListener implements ServletContextListener{

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		System.out.println("监听器销毁了----------");
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		SDKConfig.getConfig().loadPropertiesFromSrc();
		System.out.println("监听器创建了----------");
	}

}
