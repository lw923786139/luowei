package com.example.comtroller;


import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.pojo.Commodity;


@Controller
public class MainController {
	
	@RequestMapping("/")
	public String showIndex() {
		System.out.println("showIndex()");
		return "index";
	}
	
	@RequestMapping("pay/msginfo")
	public String msginfo(Map<String,Object> map,Commodity commodity) {
		System.out.println("msginfo()");
		map.put("name", commodity.getName());
		map.put("price", commodity.getPrice());
		return "msginfo";
	}
	
}
