package com.example.configuration;

import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.listener.UniompayListener;



@Configuration
public class Config {
	@Bean
	public ServletListenerRegistrationBean<UniompayListener> servletListenerRegistrationBean(){
		return new ServletListenerRegistrationBean<UniompayListener>(new UniompayListener());
	}
}
