package com.example.pojo;

import java.io.Serializable;

public class Commodity implements Serializable {
	private static final long serialVersionUID = 1158992983644669726L;
	
	private String name;
	private Integer price;
	
	
	public Commodity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Commodity(String name, Integer price) {
		super();
		this.name = name;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	
	
}
